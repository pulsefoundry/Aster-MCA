"""Export a completed, replay-verified experiment. Never accesses hardware."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def main():
    run=HERE/'cs137-wait-sweep-01'
    a=json.loads((run/'analysis/summary.json').read_text())
    plan=a['experiment'];assert plan['completed'] and len(plan['blocks'])==18
    assert a['all_frames_histograms_and_timing_sums_verified']
    restore=json.loads((run/'restored-baseline-state.json').read_text())
    assert restore['phinfo']['fault']==0 and restore['phinfo']['wait_limit_us']==10000
    decision=json.loads((run/'analysis/decision.json').read_text())
    out=ROOT/'outputs/Aster-MCA-Nano-等待上限复位对照-20261118-fast7'
    out.mkdir(exist_ok=False);shutil.copytree(run,out/'source-experiment')
    for name in ['summary.json','decision.json','wait-deadline-comparison.png']:
        shutil.copy2(run/'analysis'/name,out/name)
    for name in ['experiment-plan.json','software-verification.json','empty-check-summary.json']:
        shutil.copy2(HERE/name,out/name)
    flash=Path((HERE/'latest-flash-path.txt').read_text().strip())
    shutil.copy2(flash/'verification.json',out/'flash-verification.json')
    fw=ROOT/'firmware/at32-peakhold-fast7'
    shutil.copytree(fw,out/'firmware',ignore=shutil.ignore_patterns('build','__pycache__'))
    shutil.copy2(fw/'build/manifest.json',out/'firmware-manifest.json')
    shutil.copy2(HERE/'package_wait_experiment.py',out/'package-source.py')
    rows=['Aster MCA Nano：等待上限/复位对照，fast.7，2026-11-18','',
          '探头/源条件：'+plan['condition'],
          '固定CPU144MHz、ADC72MHz、RAW500kSa/s、PEAK24.5周期、EARLY、捕获窗6us、额外读前延迟1us。',
          '硬件R105单颗10kΩ、C101100pF，本轮未改焊。',
          '10ms/1ms/0.5ms各6组，每组30秒，位置与平均时间均衡交替；比较完整新采集的谱。',
          '未根据wait_cycles或能量挑选窄峰子集。基础质量选择与此前一致，额外保守排除max(PEAK)>=2048码。',
          '每道2个ADC幅度码；均值PEAK减事件前RAW基线；未做多点能量标定。','',
          '等待上限ms,墙钟s,收到,入谱,入谱/墙钟s,峰位道,表观FWHM/峰位%,条件统计SE百分点,模型D/dof,武装时段占墙钟,超时取消在途触发数']
    for g in a['groups'].values():
        f=g['primary_fit']
        rows.append(f"{g['wait_us']/1000:g},{g['wall_seconds']:.3f},{g['received']},{g['selected']},"
                    f"{g['selected_per_wall_second']:.3f},{f['centroid_channel']:.3f},"
                    f"{f['apparent_fwhm_percent']:.3f},{f['apparent_fwhm_statistical_se_pp']:.3f},"
                    f"{f['deviance_per_dof']:.3f},{g['armed_observed_fraction_of_wall']:.5f},"
                    f"{g['timing']['deadline_pending_n']}")
    rows+=['','结论：'+decision['conclusion']]+decision.get('report_notes_zh',[])+['',
          '计时：等待截止从ph_prepare之前计时，包含复位释放、DMA预填、武装及等待HOLD中断。',
          '它不是两个真实探头脉冲的间隔，也不是硬件精确定义的触发门宽；轮询/中断可能有小幅越界，已记录。',
          'armed_observed_cycles从武装到HOLD中断或超时取消，包括捕获窗和中断延迟，不是外部校准的真实活时间。',
          'prepare_cycles与武装时段有部分重叠，不能相加作为互斥时间预算；墙钟含USB上传与主机间隔。',
          '故障/CRC/计数/直方图/时间累计均回放核对；带重复边沿标记不等于真实堆积。',
          'Gaussian+非负线性连续谱拟合使用未平滑计数；主区间固定120..180道；其他区间结果在summary.json。',
          '统计误差不覆盖模型、拟合区间、增益/零点与实验条件误差。',
          '不能单凭本试验定位到峰值保持、ADC、复位或探头内部链路，也不构成探测器本征分辨率结论。',
          '采集结束后已恢复10ms对照、500k RAW、24.5周期PEAK、EARLY；HOLD/RESET1/1，无采集运行。',
          'source-experiment保存完整原始帧和批次头；firmware为分析/采集代码快照，运行需要原项目依赖布局。']
    (out/'README.txt').write_text('\n'.join(rows)+'\n')
    hashes={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in sorted(out.rglob('*')) if f.is_file()}
    (out/'sha256-files.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n')
    archive=out.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(out.rglob('*')):
            if f.is_file():z.write(f,str(f.relative_to(out)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in hashes.items())
    cp=ROOT/'work/peakhold-detector-20261118/checkpoint.json'
    c=json.loads(cp.read_text());c.update(status='fast.7 balanced wait-deadline experiment completed; frames/counters/timing verified, baseline restored, report archived. No active acquisition.',
        updated=datetime.datetime.now().astimezone().isoformat(),active_capture=None,final_phinfo=restore['phinfo'])
    c['wait_deadline_experiment'].update(status='complete',source_analysis=str(run/'analysis/summary.json'),
        decision=str(run/'analysis/decision.json'),export=str(out),archive=str(archive))
    c['pending']=['No ongoing measurement; await next user request before additional bench changes.']
    cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(export=str(out),archive=str(archive),bytes=archive.stat().st_size,hashes_verified=True),ensure_ascii=False))


if __name__=='__main__':main()
