Aster MCA Nano：0.5ms等待上限，铯源10分钟，2026-11-18

条件：User requests600second continuation of preceding original powered negative-pulse detector/Cs137 setup; no source,wiring,HV or gain changes reported,scope remains removed. R105single10k,C101100pF. fast.7,wait500us,window6us,PEAK24.5cycles,RAW500k,EARLY.
fast.7；CPU144MHz，ADC72MHz，RAW500kSa/s，PEAK24.5周期，EARLY，捕获窗6us，额外读前延迟1us。
R105单颗10kΩ、C101100pF；本轮没有重新烧录或改焊。
完整采集599.997秒墙钟，收到102346事件；基础入谱101288。
另排除1条超过保守模拟范围的基础入谱事件，最终入谱101287，约168.81次/墙钟秒。
原始帧/CRC、基础直方图、全部计数与内部计时累计已离线回放核对；原始数据没有修改。
主拟合success=True；峰位152.012道，FWHM13.173道，表观FWHM/峰位8.666%。
不同拟合区间给出8.39%..9.07%；主模型D/dof=7.34，条件统计误差不含模型/区间系统误差。
约一分钟分段的峰位跨度为平均峰位的0.515%，首尾变化-0.217%。
分段边界根据批次主机时长近似重建，不是单事件时间戳，也未做事后漂移平移或选取最窄时间段。
每道2个ADC幅度码；未做多点能量标定。结果是道数域表观峰宽，不是探测器本征分辨率。
等待截止从准备开始计时，包含DMA预填；不是固定每个脉冲0.5ms死时间。
armed_observed_seconds包含捕获/中断延迟，不是外部验证的真实活时间；墙钟包含USB/主机间隔。
counts继续沿用无标记/无ADC削顶/道数范围质量规则，另用max(PEAK)<2048的保守模拟范围筛选。
四次读数均值只减少非共同读噪声，不能据此排除其他取峰或探头链路误差。
当前采集已停止，保留0.5ms运行档位，HOLD/RESET1/1、fault0、selftest15。
分析代码是项目内版本快照；独立运行需恢复原项目路径与科学计算依赖。
