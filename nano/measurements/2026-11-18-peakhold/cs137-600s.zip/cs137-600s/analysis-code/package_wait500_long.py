"""Package verified600second wait500us source acquisition; no board access."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def main():
    run=Path((HERE/'latest-wait500-long-path.txt').read_text().strip())
    data=json.loads((run/'spectrum.json').read_text())
    a=json.loads((run/'analysis/analysis.json').read_text())
    valid=json.loads((run/'analysis/valid-range-spectrum.json').read_text())
    assert data['completed'] and not data.get('error') and 599.9<=data['wall_seconds']<601
    assert a['quality']['all_payload_crcs_and_histograms_verified'] and a['quality']['all_internal_timing_sums_verified']
    assert data['final']['fault']==0 and data['final']['selftest']==15 and data['final']['wait_limit_us']==500
    assert valid['selected']==a['quality']['selected']==a['totals']['binned']
    out=ROOT/'outputs/Aster-MCA-Nano-铯源10分钟-0.5ms-20261118-fast7'
    out.mkdir(exist_ok=False);shutil.copytree(run,out/'source-10min')
    for name in ['spectrum-and-fit.png','drift.png','fit-residuals.png','valid-range-spectrum.json']:
        if (run/'analysis'/name).exists():shutil.copy2(run/'analysis'/name,out/name)
    code=out/'analysis-code';code.mkdir()
    for p in [HERE/'analyze_wait500_long.py',HERE/'package_wait500_long.py',
              ROOT/'work/peakhold-detector-20261118/analyze_long_run.py',
              ROOT/'firmware/at32-peakhold-fast7/capture_spectrum.py',
              ROOT/'firmware/at32-peakhold-fast7/read_timing.py',
              ROOT/'firmware/at32-bringup/read_baseline.py']:
        shutil.copy2(p,code/p.name)
    shutil.copy2(ROOT/'firmware/at32-peakhold-fast7/build/manifest.json',out/'firmware-manifest.json')
    shutil.copy2(ROOT/'work/peakhold-detector-20261118/fit-runtime-package-metadata.json',out/'fit-runtime-metadata.json')
    primary=a['primary'];widths=[f['apparent_fwhm_percent'] for f in [primary,*a['window_sensitivity']] if f['success']]
    prior=json.loads((HERE/'cs137-wait-sweep-01/analysis/summary.json').read_text())['groups']['500']
    summary=dict(firmware='0.4.1-fast.7',wait_limit_us=500,wall_seconds=data['wall_seconds'],
        input_condition=data['input_condition'],totals=data['totals'],valid_range_selected=valid['selected'],
        valid_range_wall_cps=valid['selected']/data['wall_seconds'],primary=primary,
        roi_sensitivity_range_percent=[min(widths),max(widths)] if widths else None,
        drift=a['drift'],quality=a['quality'],internal_timing_sums=data['internal_timing_sums'],
        armed_observed_seconds=a['armed_observed_seconds'],true_live_time_measured=False,
        preceding_same_setting=dict(wall_seconds=prior['wall_seconds'],selected=prior['selected'],
                                   primary_fit=prior['primary_fit'],wall_cps=prior['selected_per_wall_second']),
        limitations=a['limitations'])
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    drift=a['drift'] or {}
    interval=(f"{min(widths):.2f}%..{max(widths):.2f}%" if widths else '无可靠拟合')
    lines=['Aster MCA Nano：0.5ms等待上限，铯源10分钟，2026-11-18','',
        '条件：'+data['input_condition'],
        'fast.7；CPU144MHz，ADC72MHz，RAW500kSa/s，PEAK24.5周期，EARLY，捕获窗6us，额外读前延迟1us。',
        'R105单颗10kΩ、C101100pF；本轮没有重新烧录或改焊。',
        f"完整采集{data['wall_seconds']:.3f}秒墙钟，收到{data['totals']['received']}事件；基础入谱{data['totals']['binned']}。",
        f"另排除{valid['additionally_excluded_analog_high']}条超过保守模拟范围的基础入谱事件，最终入谱{valid['selected']}，约{summary['valid_range_wall_cps']:.2f}次/墙钟秒。",
        '原始帧/CRC、基础直方图、全部计数与内部计时累计已离线回放核对；原始数据没有修改。',
        f"主拟合success={primary['success']}；峰位{primary['centroid_channel']:.3f}道，FWHM{primary['fwhm_channels']:.3f}道，表观FWHM/峰位{primary['apparent_fwhm_percent']:.3f}%。",
        f"不同拟合区间给出{interval}；主模型D/dof={primary['deviance_per_dof']:.2f}，条件统计误差不含模型/区间系统误差。",
        f"约一分钟分段的峰位跨度为平均峰位的{drift.get('centroid_range_percent_of_mean',float('nan')):.3f}%，首尾变化{drift.get('first_to_last_percent',float('nan')):.3f}%。",
        '分段边界根据批次主机时长近似重建，不是单事件时间戳，也未做事后漂移平移或选取最窄时间段。',
        '每道2个ADC幅度码；未做多点能量标定。结果是道数域表观峰宽，不是探测器本征分辨率。',
        '等待截止从准备开始计时，包含DMA预填；不是固定每个脉冲0.5ms死时间。',
        'armed_observed_seconds包含捕获/中断延迟，不是外部验证的真实活时间；墙钟包含USB/主机间隔。',
        'counts继续沿用无标记/无ADC削顶/道数范围质量规则，另用max(PEAK)<2048的保守模拟范围筛选。',
        '四次读数均值只减少非共同读噪声，不能据此排除其他取峰或探头链路误差。',
        '当前采集已停止，保留0.5ms运行档位，HOLD/RESET1/1、fault0、selftest15。',
        '分析代码是项目内版本快照；独立运行需恢复原项目路径与科学计算依赖。']
    (out/'README.txt').write_text('\n'.join(lines)+'\n')
    hashes={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in sorted(out.rglob('*')) if f.is_file()}
    (out/'sha256-files.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n')
    archive=Path(str(out)+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(out.rglob('*')):
            if f.is_file():z.write(f,str(f.relative_to(out)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in hashes.items())
    cp=ROOT/'work/peakhold-detector-20261118/checkpoint.json';c=json.loads(cp.read_text())
    c.update(status='Requested600s wait500us source run completed, replay/peak/drift analysis and archive verified; idle in500us profile. No active capture.',
             updated=datetime.datetime.now().astimezone().isoformat(),active_capture=None,final_phinfo=data['final'])
    c['selected_config']['wait_limit_us']=500
    c['wait500_long_capture'].update(status='complete',analysis=str(run/'analysis/analysis.json'),
                                    export=str(out),archive=str(archive),totals=data['totals'])
    c['pending']=['No ongoing measurement. Await next user request before further bench operations.']
    cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(export=str(out),archive=str(archive),bytes=archive.stat().st_size,all_hashes_verified=True),ensure_ascii=False))


if __name__=='__main__':main()
